from django.apps import AppConfig


class CommonUtilsConfig(AppConfig):
    name = 'common_utils'
