from django.apps import AppConfig


class CorpusConfig(AppConfig):
    name = 'corpus'
