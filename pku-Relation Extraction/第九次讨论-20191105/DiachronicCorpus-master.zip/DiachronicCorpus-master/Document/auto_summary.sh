#!/bin/sh

python2.7 auto_summary.py -o SUMMARY.md -f >>/dev/null
