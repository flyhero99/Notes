<template>
  <div class="footer">
    <!--<p>&copy; Copyright 2018 by <a href="mailto:wuxian94@pku.edu.cn">Xian Wu</a>.</p>-->
    <p>Powered by Django, Vue.js and ECharts.</p>
  </div>
</template>

<script>
export default {
  name: 'dcFooter'
}
</script>

<style scoped>
.footer {
  text-align: center;
  vertical-align: center;
}
</style>
