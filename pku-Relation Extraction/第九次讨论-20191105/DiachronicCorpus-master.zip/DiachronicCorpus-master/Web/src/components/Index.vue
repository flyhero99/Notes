<template>
  <el-container>
    <el-main>
      <h1>
        PKU ICL Diachronic Corpus
      </h1>
    </el-main>
  </el-container>
</template>

<script>
export default {
  name: 'index'
}
</script>

<style scoped>
.el-main {
  font-size: 40px;
  text-align: center;
}
</style>
