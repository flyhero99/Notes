from django.apps import AppConfig


class EntryEditorConfig(AppConfig):
    name = 'entry_editor'
